#include "pch.h"
#include "AntiDebugger.h"
#include "NativeAPI.h"



volatile
VOID __stdcall MakeInt3Break(PVOID pAntiDebugger)
{
	__debugbreak();
	return;
}

LONG WINAPI HasHWBVectoredExceptionHandler(PEXCEPTION_POINTERS pExceptionInfo)
{

	if (pExceptionInfo->ExceptionRecord->ExceptionCode == EXCEPTION_BREAKPOINT)
	{
		// ����Ӳ��...
		AntiDebugger* anti = (AntiDebugger*)pExceptionInfo->ContextRecord->Rcx;
		if (pExceptionInfo->ContextRecord->Dr0 != 0 ||
			pExceptionInfo->ContextRecord->Dr1 != 0 ||
			pExceptionInfo->ContextRecord->Dr2 != 0 ||
			pExceptionInfo->ContextRecord->Dr3 != 0)
		{
			// ֪ͨantiʵ��������Ӳ��
			//anti->_hasHWB = TRUE;

			// �Ƴ�Ӳ��...
			pExceptionInfo->ContextRecord->Dr0 = 0;
			pExceptionInfo->ContextRecord->Dr1 = 0;
			pExceptionInfo->ContextRecord->Dr2 = 0;
			pExceptionInfo->ContextRecord->Dr3 = 0;
		}

		// Խ��int 3 
		pExceptionInfo->ContextRecord->Rip = pExceptionInfo->ContextRecord->Rip + 1;

		return EXCEPTION_CONTINUE_EXECUTION;
	}

	return EXCEPTION_CONTINUE_SEARCH;
}

BOOL AntiDebugger::PushModule(PVOID hModule, const std::string& segName)
{
	if (hModule)
	{
		PEInfoProvider peinfo((HMODULE)hModule);
		if (peinfo.IsValidPEModule())
		{
			CodeSegCRC32 codeSeg;
			PVOID pSegAddr = nullptr;
			DWORD SegSize = 0;

			peinfo.FindSection(segName, &pSegAddr, &SegSize);

			codeSeg.VA = pSegAddr;
			codeSeg.Size = SegSize;
			codeSeg.Crc32 = DynamicCrc32::Compute((unsigned char*)pSegAddr, SegSize);

			_codesCrc32.push_back(codeSeg);
			return TRUE;
		}
	}
	return FALSE;
}

AntiDebugger::AntiDebugger()
{
	_initialized = FALSE;
	_hasHWB = FALSE;
	_isMakeHWBCheck = FALSE;
	_codesCrc32 = {};
	
	this->PushModule(g_native.pfnLoadLibraryW(L"NTDLL.dll"), CODE_SEG_NAME);
	this->PushModule(g_native.pfnGetModuleHandleW(L"KillerAid.exe"), CODE_SEG_NAME);
	this->PushModule(g_native.pfnGetModuleHandleW(L"KillerAid.Core.dll"), CODE_SEG_NAME);

}


BOOL AntiDebugger::HasDebugger()
{
	typedef struct _MYOBJECT_HANDLE_FLAG_INFORMATION
	{
		BOOLEAN Inherit;
		BOOLEAN ProtectFromClose;
	} MYOBJECT_HANDLE_FLAG_INFORMATION, * PMYOBJECT_HANDLE_FLAG_INFORMATION;

	typedef enum _MYOBJECT_INFORMATION_CLASS
	{
		ObjectBasicInformation, // OBJECT_BASIC_INFORMATION
		ObjectNameInformation, // OBJECT_NAME_INFORMATION
		ObjectTypeInformation, // OBJECT_TYPE_INFORMATION
		ObjectTypesInformation, // OBJECT_TYPES_INFORMATION
		ObjectHandleFlagInformation, // OBJECT_HANDLE_FLAG_INFORMATION
		ObjectSessionInformation,
		ObjectSessionObjectInformation,
		MaxObjectInfoClass
	} MYOBJECT_INFORMATION_CLASS;

	typedef NTSTATUS(WINAPI* fnNtSetInformationObject)(
		 HANDLE Handle,
		 MYOBJECT_INFORMATION_CLASS ObjectInformationClass,
		 PVOID ObjectInformation,
		 ULONG ObjectInformationLength
		);

	BOOL isDebugged;
	HANDLE processHandle1 = nullptr;
	HANDLE processHandle2 = nullptr;
	MYOBJECT_HANDLE_FLAG_INFORMATION objInfo = { 0 };



	if (g_native.pfnIsDebuggerPresent())
	{
		Killer();
		return TRUE;
	}
	if (!g_native.pfnCheckRemoteDebuggerPresent(g_native.pfnGetCurrentProcess(), &isDebugged))
	{
		Killer();
		return TRUE;
	}
	if (isDebugged)
	{
		Killer();
		return TRUE;
	}

	__try {
		g_native.pfnCloseHandle((void*)0xDEADC0DE);
	}
	__except (EXCEPTION_EXECUTE_HANDLER) {
		Killer();
		return TRUE;
	}

	__try {
		objInfo.Inherit = false;
		objInfo.ProtectFromClose = true;

		fnNtSetInformationObject pfnNtSetInformationObject = (fnNtSetInformationObject)g_native.pfnGetProcAddress(g_native.pfnGetModuleHandleW(L"ntdll.dll"), "ZwSetInformationObject");
		if (pfnNtSetInformationObject == nullptr)
			return FALSE;

		processHandle1 = g_native.pfnGetCurrentProcess();
		g_native.pfnDuplicateHandle(processHandle1, processHandle1, processHandle1, &processHandle2, 0, FALSE, 0);
		pfnNtSetInformationObject(processHandle2, ObjectHandleFlagInformation, &objInfo, sizeof(objInfo));
		g_native.pfnDuplicateHandle(processHandle1, processHandle2, processHandle1, &processHandle2, 0, FALSE, DUPLICATE_CLOSE_SOURCE);
	}
	__except (EXCEPTION_EXECUTE_HANDLER) {
		Killer();
		return TRUE;
	}

	DbgInfo("HasDebugger ok.");

	return FALSE;


}

BOOL AntiDebugger::HasHWB()
{
	if (!_isMakeHWBCheck)
	{
		_isMakeHWBCheck = TRUE;
		PVOID pRet = g_native.pfnAddVectoredContinueHandler(0, HasHWBVectoredExceptionHandler);
	}

	if (_hasHWB)
	{
		Killer();
		return TRUE;
	}

	CONTEXT	ctx = { 0 };
	ctx.ContextFlags = CONTEXT_DEBUG_REGISTERS;
	if (g_native.pfnGetThreadContext((HANDLE)-2, &ctx))
	{
		if (ctx.Dr0 != 0 || ctx.Dr1 != 0 || ctx.Dr2 != 0 || ctx.Dr3 != 0)
		{
			Killer();
			return TRUE;
		}
	}

	DbgInfo("HasHWB ok.");
	return FALSE;
}

BOOL AntiDebugger::HasPatcher()
{
	for (size_t i = 0; i < _codesCrc32.size(); i++)
	{
		if (DynamicCrc32::Compute((unsigned char*)_codesCrc32[i].VA, _codesCrc32[i].Size) != _codesCrc32[i].Crc32)
		{
			Killer();
			return TRUE;
		}
	}

	DbgInfo("HasPatcher ok.");
	return FALSE;
}

BOOL AntiDebugger::Execute()
{
	HasDebugger();

	HasHWB();

	HasPatcher();

	AntiManagedDebugger::Execute();

	return TRUE;
}


