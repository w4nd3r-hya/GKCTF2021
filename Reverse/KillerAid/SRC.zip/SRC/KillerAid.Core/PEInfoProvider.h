#ifndef _PE_INFO_PROVIDER_H
#define _PE_INFO_PROVIDER_H

#include "pch.h"


class PEInfoProvider
{
private:
	PVOID	_pImageBase;
	PVOID	_pImageEnd;
	PVOID	_pFirstSection;
	WORD	_numberOfSections;
	bool _IsOk;

public:

	PVOID GetImageBase();
	DWORD GetSizeOfImage();

	PEInfoProvider(HMODULE hModule);

	bool FindSection(const std::string& name, PVOID* pSectionStart, PDWORD pSectionSize);



	bool IsValidPEModule();

	/// <summary>
	/// ����ַ���Ƿ���ImageBase��
	/// </summary>
	/// <param name="addr">��ַ</param>
	/// <param name="size">�ֽ�</param>
	/// <returns></returns>
	bool IsValidImageAddress(PVOID addr, DWORD size);

	/// <summary>
	/// ����Ƿ�Ϊ����ָ��
	/// </summary>
	/// <param name="ptr"></param>
	/// <returns></returns>
	bool IsAlignedPointer(PVOID ptr);
};


#endif // !_PE_INFO_PROVIDER_H
