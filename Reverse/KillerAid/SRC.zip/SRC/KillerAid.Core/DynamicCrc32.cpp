#include "pch.h"
#include "DynamicCrc32.h"


unsigned int DynamicCrc32::_table[256] = { 0 };
BOOL	DynamicCrc32::_isEnableUse = FALSE;

DynamicCrc32::DynamicCrc32()
{
	unsigned int seed = 0;
	unsigned int crc = 0;

	srand(time(nullptr));
	seed = rand();

	for (size_t i = 0; i < 256; i++)
	{
		crc = i;
		for (int j = 8; j > 0; j--)
		{
			if ((crc & 1) == 1)
				crc = (crc >> 1) ^ seed;
			else
				crc >>= 1;
		}
		_table[i] = crc;
	}
	_isEnableUse = TRUE;
	_instance = this;

}

DynamicCrc32::~DynamicCrc32()
{
	if (_instance)
	{
		delete _instance;
	}
}

BOOL DynamicCrc32::IsEnableUse()
{
	return _isEnableUse;
}

DynamicCrc32* DynamicCrc32::GetInstance()
{
	return _instance;
}

unsigned int DynamicCrc32::Compute(unsigned char* pData, unsigned int length)
{
	unsigned int crc32 = 0;
	crc32 = ~0;
	for (size_t i = 0; i < length; i++)
	{
		crc32 = (crc32 >> 8) ^ _table[(crc32 ^ pData[i]) & 0xFF];
	}

	return ~crc32;
}
