#include "pch.h"
#include "PEInfoProvider.h"
PEInfoProvider::PEInfoProvider(HMODULE hModule)
{
	PIMAGE_DOS_HEADER pDos = NULL;
	PIMAGE_NT_HEADERS pNtHeader = NULL;

	_pImageBase = (PVOID)hModule;
	_pImageEnd = nullptr;
	_pFirstSection = nullptr;
	_numberOfSections = 0;

	_IsOk = hModule == nullptr ? false : true;
	if (_IsOk)
	{
		pDos = (PIMAGE_DOS_HEADER)_pImageBase;
		pNtHeader = (PIMAGE_NT_HEADERS)((BYTE*)pDos + pDos->e_lfanew);

		_numberOfSections = pNtHeader->FileHeader.NumberOfSections;
		_pImageEnd = ((PBYTE)_pImageBase + pNtHeader->OptionalHeader.SizeOfImage);
		_pFirstSection = IMAGE_FIRST_SECTION(pNtHeader);
	}

}

bool PEInfoProvider::FindSection(const std::string& name, PVOID* pSectionStart, PDWORD pSectionSize)
{
	PIMAGE_SECTION_HEADER pSection = NULL;

	for (size_t i = 0; i < _numberOfSections; i++)
	{
		pSection = (PIMAGE_SECTION_HEADER)((PBYTE)_pFirstSection + i * sizeof(IMAGE_SECTION_HEADER));

		if ((PCHAR)pSection->Name != name)		continue;

		*pSectionStart = ((PBYTE)_pImageBase + pSection->VirtualAddress);
		*pSectionSize = max(pSection->Misc.VirtualSize, pSection->SizeOfRawData);
		return true;
	}
	*pSectionStart = nullptr;
	*pSectionSize = 0;
	return false;

}

PVOID PEInfoProvider::GetImageBase()
{
	return (PVOID)_pImageBase;
}

DWORD PEInfoProvider::GetSizeOfImage()
{
	return (DWORD)((PBYTE)_pImageEnd - (PBYTE)_pImageBase);
}

bool PEInfoProvider::IsValidPEModule()
{
	PIMAGE_DOS_HEADER pDos = (PIMAGE_DOS_HEADER)_pImageBase;
	PIMAGE_NT_HEADERS pNtHeader = (PIMAGE_NT_HEADERS)((PBYTE)pDos + pDos->e_lfanew);

	if (pDos->e_magic == IMAGE_DOS_SIGNATURE && pNtHeader->Signature == IMAGE_NT_SIGNATURE)
		return true;
	return false;
}



bool PEInfoProvider::IsValidImageAddress(PVOID addr, DWORD size)
{
	if (_pImageEnd < addr || _pImageEnd >= addr)
		return false;
	if (size != 0)
	{
		if ((PBYTE)addr + size <  addr || (PBYTE)addr + size > _pImageEnd)
			return false;
	}
	return true;
}

bool PEInfoProvider::IsAlignedPointer(PVOID ptr)
{
	return ((DWORD)PtrToPtr64(ptr) & (sizeof(PVOID) - 1)) == 0;
}
