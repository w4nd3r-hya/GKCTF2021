#ifndef _ANTI_DEBUGGER_H
#define _ANTI_DEBUGGER_H


#include <vector>
#include <intrin.h>
#include <thread>
#include "DynamicCrc32.h"
#include "PEInfoProvider.h"
#include "AntiManagedDebugger.h"
#include "NativeAPI.h"


#define CODE_SEG_NAME	".text"
#define HUNTKILLER_MODE		TRUE

using fnTerminateProcess = BOOL(*)(
	HANDLE hProcess,
	UINT   uExitCode
	);

#if HUNTKILLER_MODE
#define Killer()	 g_native.pfnTerminateProcess(g_native.pfnGetCurrentProcess(), 0);
#else
#define Killer()
#endif // KILLER_MODE

typedef struct _CodeSegCRC32
{
	PVOID	VA;
	DWORD	Size;
	DWORD	Crc32;
}CodeSegCRC32;

class AntiDebugger
{
public:
	BOOL						_hasHWB;

private:
	std::vector<CodeSegCRC32>	_codesCrc32;
	BOOL						_initialized;
	BOOL						_isMakeHWBCheck;
public:
	BOOL	HasDebugger();
	BOOL	HasHWB();
	BOOL	HasPatcher();
	BOOL	PushModule(PVOID hModule, const std::string& segName);

public:
	BOOL	Execute();

	AntiDebugger();


};



#endif // !_ANTI_DEBUGGER_H


