#include "pch.h"
#include "AntiManagedDebugger.h"
#include "NativeAPI.h"
const OffsetInfo AntiManagedDebugger::_Clr_info(
	0x18,	//Debugger_pid
	0x78,	//DebuggerRCThread_hEvent1
	0x10,	//Debugger_pDebuggerRCThread
	0x58,	//DebuggerRCThread_pDebugger
	0x70,	//DebuggerRCThread_shouldKeepLooping
	0x60	//DebuggerRCThread_pDebuggerIPCControlBlock
);

BOOL AntiManagedDebugger::_isDetected = FALSE;

bool AntiManagedDebugger::Execute()
{
	PVOID pDebuggerRCThread = nullptr;
	PVOID pDebuggerIPCControlBlock = nullptr;
	PVOID pShouldKeepLooping = nullptr;
	HANDLE	hEvent = nullptr;
	if (_isDetected == FALSE)
	{
		pDebuggerRCThread = FindDebuggerRCThreadAddress();
		if (pDebuggerRCThread == nullptr)
			return false;

		// �ж��йܵ�������������̵߳�ͨ��
		pDebuggerIPCControlBlock = (PVOID)((PBYTE)pDebuggerRCThread + _Clr_info.DebuggerRCThread_pDebuggerIPCControlBlock);
		*(PDWORD)pDebuggerIPCControlBlock = 0;

		pShouldKeepLooping = ((PBYTE)pDebuggerRCThread + _Clr_info.DebuggerRCThread_shouldKeepLooping);
		*(PBYTE)pShouldKeepLooping = 0;

		hEvent = (HANDLE)((PBYTE)pDebuggerRCThread + _Clr_info.DebuggerRCThread_hEvent1);
		g_native.pfnSetEvent(hEvent);

		_isDetected = TRUE;

		DbgInfo("AntiManagedDebugger::Execute	ok");

		return true;
	}

	return false;
}

PVOID AntiManagedDebugger::TryGetDebuggerRCThread(PEInfoProvider* peInfo, PVOID ptr)
{
	DWORD dwPid = 0;
	DWORD dwPid2 = 0;

	PVOID pDebuggerRCThread = nullptr;
	PVOID pDebugger = nullptr;
	PVOID pDebugger2 = nullptr;

	dwPid = g_native.pfnGetCurrentProcessId();

	__try
	{
		if ((pDebugger = (PVOID) * (DWORD64*)ptr) == nullptr)
			return nullptr;

		if (peInfo->IsAlignedPointer(pDebugger) == false)
			return nullptr;

		// ȷ��pid
		dwPid2 = *(DWORD*)((BYTE*)pDebugger + _Clr_info.Debugger_pid);
		if (dwPid != dwPid2)
			return nullptr;

		pDebuggerRCThread = *(PDWORD64*)((BYTE*)pDebugger + _Clr_info.Debugger_pDebuggerRCThread);
		if (peInfo->IsAlignedPointer(pDebuggerRCThread) == false)
			return nullptr;

		pDebugger2 = *(PDWORD64*)((BYTE*)pDebuggerRCThread + _Clr_info.DebuggerRCThread_pDebugger);
		if (pDebugger != pDebugger2)
			return nullptr;

		return pDebuggerRCThread;
	}
	__except (EXCEPTION_EXECUTE_HANDLER)
	{
		return nullptr;
	}
}

PVOID AntiManagedDebugger::FindDebuggerRCThreadAddress()
{
	PVOID sectionAddr = nullptr;
	DWORD sectionSize = 0;

	PBYTE pCur = nullptr;
	PBYTE pEnd = nullptr;

	PVOID pDebuggerRCThread = nullptr;

	// ��ȡCLRģ��
	PEInfoProvider peInfo(g_native.pfnGetModuleHandleW(L"clr.dll"));
	if (peInfo.IsValidPEModule() == false)
		return nullptr;

	// ��ȡclr.dll��data��
	if (peInfo.FindSection(".data", &sectionAddr, &sectionSize) == false)
		return nullptr;

	// ���Ի�ȡ.data����DebuggerRCThreadʵ������
	pCur = (PBYTE)sectionAddr;
	pEnd = (PBYTE)sectionAddr + sectionSize;
	while (pCur <= pEnd && (pCur += sizeof(PVOID)))
	{
		if (pDebuggerRCThread = TryGetDebuggerRCThread(&peInfo, pCur))
			return pDebuggerRCThread;	//�ɹ���ȡ
	}

	return nullptr;
}
