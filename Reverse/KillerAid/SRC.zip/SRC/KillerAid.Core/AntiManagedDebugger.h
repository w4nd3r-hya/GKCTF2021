#ifndef _ANTI_MANAGED_DEBUGGER_H_
#define _ANTI_MANAGED_DEBUGGER_H_

#include "AntiManagedDebugger.h"
#include "PEInfoProvider.h"

/// <summary>
/// ��¼Debugger��DebuggerRCThread��ĳЩ��Ҫ��Աƫ��
/// </summary>
struct OffsetInfo
{
	OffsetInfo(int pid, int hEvent1, int DebuggerRCThread, int Debugger, int shouldKeepLooping, int DebuggerIPCControlBlock)
		: Debugger_pid(pid)
		, DebuggerRCThread_hEvent1(hEvent1)
		, Debugger_pDebuggerRCThread(DebuggerRCThread)
		, DebuggerRCThread_pDebugger(Debugger)
		, DebuggerRCThread_shouldKeepLooping(shouldKeepLooping)
		, DebuggerRCThread_pDebuggerIPCControlBlock(DebuggerIPCControlBlock)
	{

	}
	int Debugger_pid;
	int DebuggerRCThread_hEvent1;
	int Debugger_pDebuggerRCThread;
	int DebuggerRCThread_pDebugger;
	int DebuggerRCThread_shouldKeepLooping;
	int DebuggerRCThread_pDebuggerIPCControlBlock;
};

/// <summary>
/// ���ڼ���йܵ���������ֹ�йܵ�������ȡ������Ϣ
/// </summary>
class AntiManagedDebugger
{
private:
	static const
		OffsetInfo _Clr_info;
	static BOOL	_isDetected;

public:
	static bool Execute();
private:
	static PVOID TryGetDebuggerRCThread(PEInfoProvider* peInfo, PVOID ptr);
	static PVOID FindDebuggerRCThreadAddress();

};

#endif // !_ANTI_MANAGED_DEBUGGER_H_


