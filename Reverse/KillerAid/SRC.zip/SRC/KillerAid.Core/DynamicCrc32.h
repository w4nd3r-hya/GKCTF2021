#ifndef _DYNAMIC_CRC32_H_
#define _DYNAMIC_CRC32_H_
#include <cstdlib>
#include <ctime>

class DynamicCrc32
{
private:
	static unsigned int _table[256];
	static DynamicCrc32* _instance;
	static BOOL			_isEnableUse;
private:
	DynamicCrc32();

public:

	~DynamicCrc32();
	static BOOL	IsEnableUse();
	static DynamicCrc32* GetInstance();
	static unsigned int Compute(unsigned char* pData, unsigned int length);
};



#endif // !_DYNAMIC_CRC32_H_
