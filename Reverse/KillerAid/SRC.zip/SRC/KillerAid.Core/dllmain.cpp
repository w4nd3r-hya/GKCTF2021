﻿// dllmain.cpp : 定义 DLL 应用程序的入口点。
#include "pch.h"
#include "AntiDebugger.h"
#include "NativeAPI.h"
#include "aes.h"

#pragma region Global

uint8_t g_key[] = { rand(), rand(), rand(), rand(), rand(), rand(), rand(), rand(), rand(), rand(), rand(), rand(), rand(), rand(), rand(), rand() };
uint8_t g_iv[] = { rand(), rand(), rand(), rand(), rand(), rand(), rand(), rand(), rand(), rand(), rand(), rand(), rand(), rand(), rand(), rand() };
uint8_t g_encData[] = { 0xf6,0x1c,0xe3,0xd7,0xf9,0xfb,0x0b,0x1a,0x8b,0xa2,0x1d,0xd8,0x97,0x94,0x05,0xc4,0x6d,0x97,0xe7,0x62,0xb6,0x7c,0xef,0x9a,0x88,0x1b,0xa4,0x4d,0xfd,0xb0,0xe4,0x6e };
DynamicCrc32* DynamicCrc32::_instance = new DynamicCrc32();
NativeAPI g_native;
AntiDebugger g_anti;

#pragma endregion

#pragma region Check && Anti debugger



DWORD WINAPI ThreadProc(_In_ LPVOID lpParameter)
{
    while (true)
    {
        g_anti.Execute();
        g_native.pfnSleep(500);
    }
}
class Delegate
{
public:
    Delegate()
    {
        g_native.pfnCreateThread(NULL, 0, ThreadProc, NULL, 0, NULL);
    }
};
Delegate g_delegateExecute;

#pragma endregion

#pragma region Crypto

#ifdef _DEBUG
uint8_t* AES_DecryptPro(uint8_t* encData, size_t sizeofData, uint8_t* key, uint8_t* iv, uint32_t rounds)
{
    uint8_t* Ivs = nullptr;
    uint8_t* Keys = nullptr;

    struct AES_ctx ctx;

    Ivs = new uint8_t[rounds * AES_BLOCKLEN]();
    Keys = new uint8_t[rounds * AES_BLOCKLEN]();

    // 迭代出所有 k 与 iv
    for (size_t i = 0; i < rounds; i++)
    {
        memcpy(Ivs + i * AES_BLOCKLEN, iv, AES_BLOCKLEN);
        memcpy(Keys + i * AES_BLOCKLEN, key, AES_BLOCKLEN);

        // 对 iv 进行 sbox 替代 后 k 用 iv 异或更新
        SubBytes((state_t*)iv);
        XorWithIv(key, iv);
        // 对 k 进行 sbox 替代 后 iv 用 k 异或更新
        SubBytes((state_t*)key);
        XorWithKey(iv, key);
    }

    // 解密流
    for (size_t i = 1; i <= rounds; i++)
    {
        key = (uint8_t*)(Keys + (rounds - i) * AES_BLOCKLEN);
        iv = (uint8_t*)(Ivs + (rounds - i) * AES_BLOCKLEN);
        AES_init_ctx_iv(&ctx, key, iv);
        AES_CBC_decrypt_buffer(&ctx, encData, sizeofData);
    }
    delete[] Ivs;
    delete[] Keys;

    return encData;
}
    #define DecryptPro(encData, sizeofData, key, iv, rounds) AES_DecryptPro(encData, sizeofData, key, iv, rounds)
#else
    #define DecryptPro(encData, sizeofData, key, iv, rounds)
#endif // _DEBUG

uint8_t* AES_EncryptPro(uint8_t* data, size_t sizeofData, uint8_t* ukey, uint8_t* uiv, uint32_t rounds)
{
    struct AES_ctx ctx;
    uint8_t key[16], iv[16];
    memcpy(key, ukey, AES_BLOCKLEN);
    memcpy(iv, uiv, AES_BLOCKLEN);
    do
    {
        AES_init_ctx_iv(&ctx, key, iv);
        AES_CBC_encrypt_buffer(&ctx, data, sizeofData); // Kn + IVn --(Aes-cbc 128)--> D(n+1)

        // 对 iv 进行 sbox 替代 后 k 用 iv 异或更新
        SubBytes((state_t*)iv);
        XorWithIv(key, iv);
        // 对 k 进行 sbox 替代 后 iv 用 k 异或更新
        SubBytes((state_t*)key);
        XorWithKey(iv, key);
    } while (--rounds);

    return data;
}

#pragma endregion

#pragma region DLL Export

extern "C" __declspec(dllexport)
void LoadDLL(int major)
{

}

extern "C" __declspec(dllexport)
bool CheckCode(char* code)
{
    // id : ginkgo_CX
    //code:Meaningless_!$!%*@^%#%_Code
    uint8_t* data = nullptr;
    size_t   sizeofCode = 0;
    size_t   sizeOfData = 0;
    bool     result = false;
    sizeofCode = strlen(code);    //统计字符串code长度

    sizeOfData = sizeofCode + AES_BLOCKLEN - sizeofCode % AES_BLOCKLEN;    //用AES_BLOCKLEN对齐长度

    data = new uint8_t[sizeOfData](); // new 并全部初始化为0

    memcpy(data, code, sizeofCode);

    AES_EncryptPro(data, sizeOfData, g_key, g_iv, 32);   //加密

    result = !memcmp(data, g_encData, sizeOfData);       //比较

    DecryptPro(data, sizeOfData, g_key, g_iv, 32);

    delete[] data;

    return result;
}

#pragma endregion


BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
                     )
{
    switch (ul_reason_for_call)
    {
    case DLL_PROCESS_ATTACH:
    {
        ::LoadLibraryW(L"ntdll.dll");
        break;
    }
    case DLL_THREAD_ATTACH:
    case DLL_THREAD_DETACH:
    case DLL_PROCESS_DETACH:
        break;
    }
    return TRUE;
}


