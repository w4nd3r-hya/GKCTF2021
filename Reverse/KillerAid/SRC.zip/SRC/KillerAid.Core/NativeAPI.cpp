#include "pch.h"
#include "NativeAPI.h"

NativeAPI::fnCreateThread NativeAPI::pfnCreateThread = nullptr;
NativeAPI::fnGetThreadContext NativeAPI::pfnGetThreadContext = nullptr;
NativeAPI::fnLoadLibraryW NativeAPI::pfnLoadLibraryW = nullptr;
NativeAPI::fnGetModuleHandleW NativeAPI::pfnGetModuleHandleW = nullptr;
NativeAPI::fnAddVectoredContinueHandler NativeAPI::pfnAddVectoredContinueHandler = nullptr;
NativeAPI::fnCloseHandle NativeAPI::pfnCloseHandle = nullptr;
NativeAPI::fnCheckRemoteDebuggerPresent NativeAPI::pfnCheckRemoteDebuggerPresent = nullptr;
NativeAPI::fnIsDebuggerPresent NativeAPI::pfnIsDebuggerPresent = nullptr;
NativeAPI::fnGetProcAddress NativeAPI::pfnGetProcAddress = nullptr;
NativeAPI::fnDuplicateHandle NativeAPI::pfnDuplicateHandle = nullptr;
NativeAPI::fnSetEvent NativeAPI::pfnSetEvent = nullptr;
NativeAPI::fnGetCurrentProcessId NativeAPI::pfnGetCurrentProcessId = nullptr;
NativeAPI::fnGetCurrentProcess NativeAPI::pfnGetCurrentProcess = nullptr;
NativeAPI::fnSleep NativeAPI::pfnSleep = nullptr;
NativeAPI::fnTerminateProcess NativeAPI::pfnTerminateProcess = nullptr;

NativeAPI::NativeAPI()
{
	HMODULE hKernel32 = GetModuleHandle(TEXT("kernel32.dll"));
	if (hKernel32 == NULL)
	{
		return;
	}
	pfnGetProcAddress = (fnGetProcAddress)GetProcAddress(hKernel32, "GetProcAddress");
	pfnCreateThread = (fnCreateThread)pfnGetProcAddress(hKernel32, "CreateThread");
	pfnGetThreadContext = (fnGetThreadContext)pfnGetProcAddress(hKernel32, "GetThreadContext");
	pfnLoadLibraryW = (fnLoadLibraryW)pfnGetProcAddress(hKernel32, "LoadLibraryW");
	pfnGetModuleHandleW = (fnGetModuleHandleW)pfnGetProcAddress(hKernel32, "GetModuleHandleW");
	pfnAddVectoredContinueHandler = (fnAddVectoredContinueHandler)pfnGetProcAddress(hKernel32, "AddVectoredContinueHandler");
	pfnCloseHandle = (fnCloseHandle)pfnGetProcAddress(hKernel32, "CloseHandle");
	pfnCheckRemoteDebuggerPresent = (fnCheckRemoteDebuggerPresent)pfnGetProcAddress(hKernel32, "CheckRemoteDebuggerPresent");
	pfnIsDebuggerPresent = (fnIsDebuggerPresent)pfnGetProcAddress(hKernel32, "IsDebuggerPresent");
	pfnDuplicateHandle = (fnDuplicateHandle)pfnGetProcAddress(hKernel32, "DuplicateHandle");
	pfnSetEvent = (fnSetEvent)pfnGetProcAddress(hKernel32, "SetEvent");
	pfnGetCurrentProcessId = (fnGetCurrentProcessId)pfnGetProcAddress(hKernel32, "GetCurrentProcessId");
	pfnGetCurrentProcess = (fnGetCurrentProcess)pfnGetProcAddress(hKernel32, "GetCurrentProcess");
	pfnSleep = (fnSleep)pfnGetProcAddress(hKernel32, "Sleep");
	pfnTerminateProcess = (fnTerminateProcess)pfnGetProcAddress(hKernel32, "TerminateProcess");
	
}


