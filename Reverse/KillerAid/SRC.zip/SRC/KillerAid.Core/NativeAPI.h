#ifndef _NATIVE_API_H_
#define _NATIVE_API_H_
#include <Windows.h>

static
class NativeAPI
{
    using fnCreateThread = HANDLE(WINAPI*)(_In_opt_ LPSECURITY_ATTRIBUTES lpThreadAttributes,
        _In_ SIZE_T dwStackSize,
        _In_ LPTHREAD_START_ROUTINE lpStartAddress,
        _In_opt_ __drv_aliasesMem LPVOID lpParameter,
        _In_ DWORD dwCreationFlags,
        _Out_opt_ LPDWORD lpThreadId
        );

    using fnLoadLibraryW = HMODULE(WINAPI*)(
            _In_ LPCWSTR lpLibFileName
        );

    using fnGetModuleHandleW = HMODULE(WINAPI*)(
        _In_ LPCWSTR lpLibFileName
        );

    using fnGetThreadContext = BOOL (*)(
        HANDLE    hThread,
        LPCONTEXT lpContext
    );

    using fnAddVectoredContinueHandler = PVOID (*)(
        ULONG                       First,
        PVECTORED_EXCEPTION_HANDLER Handler
    );

    using fnCloseHandle = BOOL (*)(
        HANDLE hObject
    );

    using fnCheckRemoteDebuggerPresent = BOOL (*)(
        HANDLE hProcess,
        PBOOL  pbDebuggerPresent
    );

    using fnIsDebuggerPresent = BOOL (*)();

    using fnGetProcAddress = FARPROC (*)(
        HMODULE hModule,
        LPCSTR  lpProcName
    );

    using fnDuplicateHandle = BOOL (*)(
        HANDLE   hSourceProcessHandle,
        HANDLE   hSourceHandle,
        HANDLE   hTargetProcessHandle,
        LPHANDLE lpTargetHandle,
        DWORD    dwDesiredAccess,
        BOOL     bInheritHandle,
        DWORD    dwOptions
    );

    using fnSetEvent = BOOL (*)(
        HANDLE hEvent
    );

    using fnGetCurrentProcessId = DWORD (*)();
    using fnGetCurrentProcess = HANDLE(*)();
    using fnSleep = void (*)(
        DWORD dwMilliseconds
    );

    using fnTerminateProcess = BOOL (*)(
        HANDLE hProcess,
        UINT   uExitCode
    );

public:
    NativeAPI();
    static fnCreateThread pfnCreateThread;
    static fnLoadLibraryW pfnLoadLibraryW;
    static fnGetModuleHandleW pfnGetModuleHandleW;
    static fnGetThreadContext pfnGetThreadContext;
    static fnAddVectoredContinueHandler pfnAddVectoredContinueHandler;
    static fnCloseHandle pfnCloseHandle;
    static fnCheckRemoteDebuggerPresent pfnCheckRemoteDebuggerPresent;
    static fnIsDebuggerPresent pfnIsDebuggerPresent;
    static fnGetProcAddress pfnGetProcAddress;
    static fnDuplicateHandle pfnDuplicateHandle;
    static fnSetEvent pfnSetEvent;
    static fnGetCurrentProcessId pfnGetCurrentProcessId;
    static fnGetCurrentProcess pfnGetCurrentProcess;
    static fnSleep pfnSleep;
    static fnTerminateProcess pfnTerminateProcess;
};

extern NativeAPI g_native;

#endif // !_NATIVE_API_H_