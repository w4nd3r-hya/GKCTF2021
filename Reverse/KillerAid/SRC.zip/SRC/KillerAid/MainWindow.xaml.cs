﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace KillerAid
{

    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        [DllImport("KillerAid.Core.dll")]
        static extern void LoadDLL();
        [DllImport("KillerAid.Core.dll")]
        static extern bool CheckCode(string code);

        public MainWindow()
        {
            InitializeComponent();
            LoadDLL();
        }

        private void WinMove_LeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.DragMove();
        }

        private void Check_Click(object sender, RoutedEventArgs e)
        {
            // id   : ginkgo_CX
            // code : Meaningless_!$!%*@^%#%_Code
            // flag :flag{ginkgo_CX@Meaningless_!$!%*@^%#%_Code}
            if (string.IsNullOrEmpty(ID.Text) || string.IsNullOrEmpty(Code.Text))
            {
                MessageBox.Show("ID 或 Code不能为空!");
                return;
            }

            byte[] id = System.Text.Encoding.ASCII.GetBytes(ID.Text);
            byte[] code = System.Text.Encoding.ASCII.GetBytes(Code.Text);
            int size = Math.Max(id.Length, code.Length);

            byte[] data = { 0x07, 0x5A, 0x73, 0x01, 0x75, 0x63, 0x72, 0x61, 0x18 };

            for (int i = 0; i < size; i++)
            {
                id[i % id.Length] ^= code[i % code.Length];
            }

            for (int i = 0; i < id.Length; i++)
            {
                if (id[i] != data[i])
                {
                    MessageBox.Show("请检查ID 或 Code 是否正确");
                    return;
                }
            }

            if (!CheckCode(Code.Text))
            {
                MessageBox.Show("请检查ID 或 Code 是否正确");
                return;
            }


            MessageBox.Show("flag{" + ID.Text + "@" + Code.Text + "}");

        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
