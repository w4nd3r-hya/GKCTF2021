const format = require('string-format');


let safeQuery =  async (username,password)=>{

    const waf = (str)=>{
        // console.log(str);
        blacklist = ['\\','\^',')','(','\"','\'']
        blacklist.forEach(element => {
            if (str == element){
                str = "*";
            }
        });
        return str;
    }

    const safeStr = (str)=>{ for(let i = 0;i < str.length;i++){
        if (waf(str[i]) =="*"){
            str =  str.slice(0, i) + "*" + str.slice(i + 1, str.length);
        }
        return str;
    }
    }
    username = safeStr(username);
    console.log(username);
    password = safeStr(password);
    let sql = format("select * from test where username = '{}' and password = '{}'",username,password);
    // console.log(sql);

}

safeQuery("123(","(");
