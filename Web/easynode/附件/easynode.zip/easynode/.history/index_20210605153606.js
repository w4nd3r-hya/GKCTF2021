const express = require('express');
const format = require('string-format')
// const bodyParser=require('body-parser')
// const tools = require('./tools');
// const { select } = require('./tools');
app = new express();

app.use(express.urlencoded())


const select = async (sql)=>{
  let data;
        this.connection = mysql.createConnection( config );
        await this.connection.query(sql, function(err,result, data){
            if(err){
                console.log(err);
            }
            // console.log(data);
            data = result;
           return result;
        }
        );
        return data;
}

async function useAuth(){
  const res =  (await axios.post('http://localhost:1337/')).data
  const raw = res.json()

  return raw
}
// var test= a();
console.log(test);
// app.post('/login',function(req,res,next){


  
  

//     let username = req.body.username;
//     let password = req.body.password;
//     // console.log('username:'+username);
//     let sql = format('select * from test where username="{}"',username);
//     var result = await select(sql);
//     console.log(result);
    
//     res.send(result);
//     // res.send(req.body);
//   })

// app.listen(1337, () => {
//     console.log(`App listening at port 1337`)
// })  