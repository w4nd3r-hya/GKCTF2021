var extend = require('js-extend').extend
 
var obj1 = { name: 'Jonny' };
var obj2 = { lastName: 'Quest' };
 
extend(obj1, obj2);
console.log(obj1);

// obj1: { name: 'Jonny', lastName: 'Quest' }