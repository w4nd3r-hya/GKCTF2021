const express = require('express');
const format = require('string-format')
// const bodyParser=require('body-parser')
// const tools = require('./tools');
const { select } = require('./tools');
const app = new express();

app.use(express.urlencoded())




app.post('/login',function(req,res,next){

    let username = req.body.username;
    let password = req.body.password;
    // console.log('username:'+username);
    let sql = format('select * from test where username="{}"',username);
    
    //  处理sql操作
    select(sql).then( (res)=>{ 
      console.log(res);
      if(res[0].username)
     } );
    
  })

app.listen(1337, () => {
    console.log(`App listening at port 1337`)
})  