<?php
class d1uKKY{
    public $Dn9M1aD;
    public function fXnC1Z($eBO2E){
		for($i = 0; $i < 1; $i ++){
			$azzc4M= $eBO2E;
		}
		if(method_exists($this->Dn9M1aD, 'dotBqH')) $this->Dn9M1aD->dotBqH($eBO2E);
		if(method_exists($this->Dn9M1aD, 'cn8EgI')) $this->Dn9M1aD->cn8EgI($eBO2E);

    }
    public function f4zfZB($tynlE){
		for($i = 0; $i < 8; $i ++){
			$aOIpS1= $tynlE;
		}
		if(method_exists($this->Dn9M1aD, 'XvuIW4')) $this->Dn9M1aD->XvuIW4($tynlE);
		if(method_exists($this->Dn9M1aD, 'ngETeB')) $this->Dn9M1aD->ngETeB($tynlE);

    }
}

class G7pPxI{
    public $RhKfBWs;
    public function MnlI7H($fd6Yx){
		if(16504>28801){
			$fd6Yx = $fd6Yx.'SGUpT';
		}
		eval($fd6Yx);

    }
    public function XvuIW4($hyHyG){
		$this->SHRyA = "H5TyI";
		$this->RhKfBWs->nCHG5Z($hyHyG);

    }
}
