const express = require('express');
var tools = require('./tools');
app = new express();


app.get("/", async (req, res) => {

    let username = req.body.username
    let password = req.body.password

    // const html = await ejs.renderFile(__dirname + "/templates/index.ejs", {services})
    // res.end(html)
})

app.listen(1337, () => {
    console.log(`App listening at port 1337`)
})  