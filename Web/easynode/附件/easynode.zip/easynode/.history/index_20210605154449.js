// const express = require('express');
// const format = require('string-format')
// // const bodyParser=require('body-parser')
// // const tools = require('./tools');
// // const { select } = require('./tools');
// const app = new express();

// app.use(express.urlencoded())

async function callback(){
  let ret;
 setTimeout( ()=>{
   ret = 123;
   console.log(123);
 } ,3000)
}

async function a(){
  
  var a = 
  console.log(a);
  
}
callback();
// var test= a();

// app.post('/login',function(req,res,next){

//     let username = req.body.username;
//     let password = req.body.password;
//     // console.log('username:'+username);
//     let sql = format('select * from test where username="{}"',username);
//     var result = await select(sql);
//     console.log(result);
    
//     res.send(result);
//     // res.send(req.body);
//   })

// app.listen(1337, () => {
//     console.log(`App listening at port 1337`)
// })  