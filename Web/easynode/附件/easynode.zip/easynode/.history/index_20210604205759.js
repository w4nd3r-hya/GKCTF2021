const express = require('express');
var tools = require('./tools');
app = new express();


tools.select("select * from test;");
// var mysql  = require('mysql');

// var connection = mysql.createConnection({
//    host     : 'localhost',
//    user     : 'root',
//    password : 'root',
//    database : 'test'
//  });


// connection.connect();

// var  sql = 'SELECT * FROM test';

 
// connection.end();
