const express = require('express');

var bodyParser=require('body-parser')
var tools = require('./tools');
app = new express();

app.use(require('body-parser').urlencoded({extended: true}));

app.post('/login',function(req,res,next){
    console.log(JSON.stringify(req.body));
    
    // var body = JSON.parse(JSON.stringify(req.body));

    
    console.log(body);
    
  })

app.listen(1337, () => {
    console.log(`App listening at port 1337`)
})  