const express = require('express');
const format = require('string-format')
// const bodyParser=require('body-parser')
// const tools = require('./tools');
const { select,close } = require('./tools');
const app = new express();

app.use(express.urlencoded())




app.post('/login',function(req,res,next){

    let username = req.body.username;
    let password = req.body.password;
    // console.log('username:'+username);
    let sql = format('select * from test where username="{}"',username);
    
    //  处理sql操作
    // select(sql).then( (res)=>{ 
    //   // console.log(res);
    //   if(res[0].password =="admin"){
    //     console.log("yes,yes,yes!");
    //   }

    //  } );
    select( 'select * from user where username= ? and password =?', [username,password] )
      .then( rows => {

        console.log('The solution is: ', rows[0]);
        if (rows[0]) {
          res.json({
            "ok": "congratulations","msg":"pls look \\kfhkhkdsdshalkhkhaklhlahlkkhdfklhhjkhgdajgfhjaghghjasgfjh\\jflkdsajklfjsakljfjkhkjhdsfgasdyuuyueuwguguiuidgffddjfj.js"
          })
        } else {
          res.json({
            "error": "cookie not set","msg":"1111111111"
          })
        }

      } )
      .then( rows => {
        otherRows = rows;
        return close();
      }, err => {
        return close().then( () => { throw err; } )
      } )
      .then( () => {
        res.json({
          "error": "err","msg":"user or pass err"
        })
      })
      .catch( err => {
        res.json({
          //"error": "err","msg":err.message
            "error": "err","msg":"user or pass err"
        })
      } )




  })

app.listen(1337, () => {
    console.log(`App listening at port 1337`)
})  