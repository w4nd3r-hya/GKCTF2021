const format = require('string-format');


let safeQuery =  async (username,password)=>{

    const waf = (str)=>{
        // console.log(str);
        // console.log(str);
        blacklist = ['\\','\^',')','(','\"','\'',' ']
        blacklist.forEach(element => {
            
            if (str == element){
                str = "*";
            }
        });
        return str;
    }

    const safeStr = (str)=>{ for(let i = 0;i < str.length;i++){
        if (waf(str[i]) =="*"){
            str =  str.slice(0, i) + "*" + str.slice(i + 1, str.length);
            // console.log(str);
        }
    }
    return str
    }
    username = safeStr(username);
    console.log(username);
    // password = safeStr(password);
    // console.log(password);
    let sql = format("select * from test where username = '{}' and password = '{}'",username.substr(0,20),password.substr(0,20));
    // let sql = format("select * from test where username = '{}' and password = '{}'",username,password);
    console.log(sql);
    
    // result = JSON.parse(JSON.stringify(await select(sql)));

}

// wdnmd = ['a ()',1,1,1,1,11]
wdnmd=["admin'#",1,2,3,4,5,"(","("]
safeQuery(wdnmd,'(');


