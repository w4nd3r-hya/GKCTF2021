const express = require('express');
const format = require('string-format')
// const tools = require('./tools');
const { select,close } = require('./tools');
const app = new express();

app.use(express.())


let safeQuery =  async (sql)=>{

    const waf = (str)=>{
        // console.log(str);
        blacklist = ['\\','\^',')','(','\"','\'']
        blacklist.forEach(element => {
            if (str == element){
                str = "*";
            }
        });
        return str;
    }

    for(let i = 0;i < sql.length;i++){
        if (waf(sql[i]) =="*"){
            sql =  sql.slice(0, i) + "*" + sql.slice(i + 1, sql.length);
        }
    }
    
    res = await select(sql);
    console.log(res);
}

app.post('/login',function(req,res,next){

    let username = req.body.username;
    let password = req.body.password;
    // console.log('username:'+username);
    let sql = format('select * from test where username="{}" and password = "{}" ',username,password);

    safeQuery(sql);
    
    // select(sql)
    //   .then( rows => {

    //     console.log('The solution is: ', rows[0]);
    //     if (rows[0]) {
    //       res.json({
    //         "ok": "congratulations","msg":"n0_0ne_We_F4ndme.js"
    //       })
    //     } else {
    //       res.json({
    //         "error": "cookie not set","msg":"1111111111"
    //       })
    //     }

    //   } )
    //   .then( rows => {
    //     otherRows = rows;
    //     return close();
    //   }, err => {
    //     return close().then( () => { throw err; } )
    //   } )
    //   .then( () => {
    //     res.json({
    //       "error": "err","msg":"user or pass err"
    //     })
    //   })
    //   .catch( err => {
    //     res.json({
    //       //"error": "err","msg":err.message
    //         "error": "err","msg":"user or pass err"
    //     })
    //   } )




  })

app.listen(1337, () => {
    console.log(`App listening at port 1337`)
})  