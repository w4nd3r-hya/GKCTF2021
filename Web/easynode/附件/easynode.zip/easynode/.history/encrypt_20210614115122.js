const fs = require('fs');
const path = require('path');
const jwt = require('jsonwebtoken');
// 创建 token 类

// const generateToken = (data)=> {
    
//     let created = Math.floor(Date.now() / 1000);
//     let cert = fs.readFileSync(path.join(__dirname, './pem/pri.key'));//私钥 可以自己生成
//     // console.log(cert);
//     let token = jwt.sign({
//         data, // 自定义字段
//         // exp: created + 60 * 30, // 过期时间 30 分钟
//         // iat: created, // 创建时间
//     }, cert, {algorithm: 'RS256'});
//     return token;
// }
const secret = 'yating';
function makeToken(name) {
    return token = jwt.sign({ name }, secret);
}

console.log(makeToken('admin'));