const express = require('express');

var bodyParser=require('body-parser')
var tools = require('./tools');
const { select } = require('./tools');
const { format } = require('mysql');
app = new express();

app.use(express.urlencoded())

app.post('/login',function(req,res,next){
    let username = req.body.username;
    let password = req.body.password;
    // console.log('username:'+username);
    sql = format('select * from test where username={}',username)
    res.send(req.body)
  })

app.listen(1337, () => {
    console.log(`App listening at port 1337`)
})  