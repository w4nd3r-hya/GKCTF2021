const express = require('express');
var tools = require('./tools');
app = new express();


app.post('/login',function(req,res,next){
    let username = req.body.username;
    let password = req.body.password;
    res.send(req.body)
  })

app.listen(1337, () => {
    console.log(`App listening at port 1337`)
})  